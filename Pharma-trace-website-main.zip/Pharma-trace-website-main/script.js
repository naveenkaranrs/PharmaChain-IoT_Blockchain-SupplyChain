// small shared helpers used by pages
// (kept minimal - pages include their own logic)
(function(){
  // expose a helper to get current trace object
  window.getCurrentTrace = function(){
    return JSON.parse(localStorage.getItem('pharmatrace_current') || 'null');
  };
  window.saveCurrentTrace = function(obj){
    localStorage.setItem('pharmatrace_current', JSON.stringify(obj));
  };
})();
