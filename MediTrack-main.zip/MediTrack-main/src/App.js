import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Login from './pages/Login';
import BatchManagement from './pages/BatchManagement';
import CreateBatch from './pages/CreateBatch';
import TransferBatch from './pages/TransferBatch';
import ViewBatches from './pages/ViewBatches'; // ✅ Added this import
import { BatchProvider } from './context/BatchContext';
import ManufacturerPage from './pages/ManufacturerPage';
import Testing from './pages/Testing';
import Shipping from './pages/Shipping';
import Delivery from './pages/Delivery';
import PatientTracking from "./pages/PatientTracking";

function App() {
  return (
    <BatchProvider>
      <Router>
        <Routes>
          <Route path="/" element={<Login />} />
          {/* <Route path="/batch-management" element={<BatchManagement />} /> */}
          <Route path="/create-batch" element={<CreateBatch />} />
          <Route path="/transfer-batch" element={<TransferBatch />} />
          <Route path="/view-batches" element={<ViewBatches />} /> {/* ✅ Added route */}
          <Route path="/batch-management" element={<ManufacturerPage/>} /> {/* ✅ Added route */}
          <Route path="/testing" element={<Testing/>} /> {/* ✅ Added route */}
          <Route path="/shipping" element={<Shipping/>} /> {/* ✅ Added route */}
          <Route path="/delivery" element={<Delivery/>} /> {/* ✅ Added route */}
          <Route path="/patient-tracking" element={<PatientTracking />} />

        </Routes>
      </Router>
    </BatchProvider>
  );
}

export default App;
