// src/Asset/Image.js
const Images = {
  Background: require('./Background.jpg'),
};

export default Images;
