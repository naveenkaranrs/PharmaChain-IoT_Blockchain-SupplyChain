// src/context/BatchContext.js
import React, { createContext, useState } from "react";

export const BatchContext = createContext();

export const BatchProvider = ({ children }) => {
  const [batches, setBatches] = useState([]); // Manufacturer stage
  const [testedBatches, setTestedBatches] = useState([]); // After testing
  const [shippedBatches, setShippedBatches] = useState([]); // After shipping
  const [deliveredBatches, setDeliveredBatches] = useState([]); // After delivery

  // ✅ 1. Manufacturer adds new batch
  const addBatch = (newBatch) => {
    setBatches((prev) => [...prev, { ...newBatch, testResult: null, shipped: false, delivered: false }]);
  };

  // ✅ 2. Testing stage (update test result)
  const updateTestResult = (batchId, data) => {
    // Update inside manufacturer list
    setBatches((prev) =>
      prev.map((b) =>
        b.batchId === batchId ? { ...b, testResult: data } : b
      )
    );

    // Add to tested list if approved
    if (data.status === "Approved") {
      const batch = batches.find((b) => b.batchId === batchId);
      if (batch && !testedBatches.some((t) => t.batchId === batchId)) {
        setTestedBatches((prev) => [...prev, { ...batch, testResult: data }]);
      }
    }
  };

  // ✅ 3. Shipping stage
  const markAsShipped = (batchId) => {
    const batch = testedBatches.find((b) => b.batchId === batchId);
    if (batch) {
      // Update lists
      setTestedBatches((prev) => prev.filter((b) => b.batchId !== batchId));
      setShippedBatches((prev) => [
        ...prev,
        { ...batch, shipped: true, delivered: false },
      ]);

      // Update manufacturer-level batch info too
      setBatches((prev) =>
        prev.map((b) =>
          b.batchId === batchId ? { ...b, shipped: true } : b
        )
      );
    }
  };

  // ✅ 4. Delivery stage
  const markAsDelivered = (batchId) => {
    const batch = shippedBatches.find((b) => b.batchId === batchId);
    if (batch) {
      // Update lists
      setShippedBatches((prev) => prev.filter((b) => b.batchId !== batchId));
      setDeliveredBatches((prev) => [
        ...prev,
        { ...batch, delivered: true },
      ]);

      // Update manufacturer-level batch info too
      setBatches((prev) =>
        prev.map((b) =>
          b.batchId === batchId ? { ...b, delivered: true } : b
        )
      );
    }
  };

  return (
    <BatchContext.Provider
      value={{
        batches,
        testedBatches,
        shippedBatches,
        deliveredBatches,
        addBatch,
        updateTestResult,
        markAsShipped,
        markAsDelivered,
      }}
    >
      {children}
    </BatchContext.Provider>
  );
};
