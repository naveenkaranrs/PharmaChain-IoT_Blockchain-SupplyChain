import React, { useState, useContext } from "react";
import {
  Container,
  Typography,
  TextField,
  Button,
  Paper,
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableRow,
  Box,
} from "@mui/material";
import { motion } from "framer-motion";
import { BatchContext } from "../context/BatchContext";

export default function ManufacturerPage() {
  const { batches, addBatch } = useContext(BatchContext);
  const [batchData, setBatchData] = useState({
    batchId: "",
    productName: "",
    manufactureDate: "",
    expiryDate: "",
    quantity: "",
  });

  const handleChange = (e) => {
    setBatchData({ ...batchData, [e.target.name]: e.target.value });
  };

  const handleSubmit = () => {
    if (
      !batchData.batchId ||
      !batchData.productName ||
      !batchData.manufactureDate ||
      !batchData.expiryDate ||
      !batchData.quantity
    ) {
      alert("Please fill all fields");
      return;
    }

    addBatch(batchData); // ✅ Save to context
    setBatchData({
      batchId: "",
      productName: "",
      manufactureDate: "",
      expiryDate: "",
      quantity: "",
    });
  };

  return (
    <Container
      maxWidth={false}
      sx={{
        width: "100vw",
        height: "100vh",
        backgroundColor: "#f5f5f5",
        padding: 4,
      }}
    >
      <motion.div
        initial={{ opacity: 0, y: -30 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 1 }}
      >
        <Typography variant="h4" sx={{ mb: 3, textAlign: "center" }}>
          Manufacturer Dashboard
        </Typography>

        <Paper sx={{ p: 3, mb: 4 }}>
          <Typography variant="h6" gutterBottom>
            Enter New Batch Details
          </Typography>

          <Box
            sx={{
              display: "grid",
              gridTemplateColumns: "repeat(auto-fit, minmax(250px, 1fr))",
              gap: 2,
              mb: 2,
            }}
          >
            <TextField
              label="Batch ID"
              name="batchId"
              value={batchData.batchId}
              onChange={handleChange}
            />
            <TextField
              label="Product Name"
              name="productName"
              value={batchData.productName}
              onChange={handleChange}
            />
            <TextField
              label="Manufacture Date"
              type="date"
              name="manufactureDate"
              InputLabelProps={{ shrink: true }}
              value={batchData.manufactureDate}
              onChange={handleChange}
            />
            <TextField
              label="Expiry Date"
              type="date"
              name="expiryDate"
              InputLabelProps={{ shrink: true }}
              value={batchData.expiryDate}
              onChange={handleChange}
            />
            <TextField
              label="Quantity"
              type="number"
              name="quantity"
              value={batchData.quantity}
              onChange={handleChange}
            />
          </Box>

          <Button variant="contained" onClick={handleSubmit}>
            Add Batch
          </Button>
        </Paper>

        <Paper sx={{ p: 3 }}>
          <Typography variant="h6" gutterBottom>
            Existing Batches
          </Typography>
          {batches.length === 0 ? (
            <Typography color="text.secondary">No batches added yet.</Typography>
          ) : (
            <Table>
              <TableHead>
                <TableRow>
                  <TableCell>Batch ID</TableCell>
                  <TableCell>Product Name</TableCell>
                  <TableCell>Manufacture Date</TableCell>
                  <TableCell>Expiry Date</TableCell>
                  <TableCell>Quantity</TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {batches.map((batch, index) => (
                  <TableRow key={index}>
                    <TableCell>{batch.batchId}</TableCell>
                    <TableCell>{batch.productName}</TableCell>
                    <TableCell>{batch.manufactureDate}</TableCell>
                    <TableCell>{batch.expiryDate}</TableCell>
                    <TableCell>{batch.quantity}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </Paper>
      </motion.div>
    </Container>
  );
}
