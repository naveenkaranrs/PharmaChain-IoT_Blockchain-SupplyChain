import React, { useState, useContext } from 'react';
import { Container, Typography, TextField, Button, Paper, Box } from '@mui/material';
import { useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import Images from '../Asset/Image';
import { BatchContext } from '../context/BatchContext';

export default function CreateBatch() {
  const navigate = useNavigate();
  const { addBatch } = useContext(BatchContext);

  const [batch, setBatch] = useState({
    batchId: '',
    medicineName: '',
    manufacturer: '',
    manufactureDate: '',
    expiryDate: '',
    quantity: '',
    price: '',
    currentOwner: '',
  });

  const handleChange = (e) => {
    setBatch({ ...batch, [e.target.name]: e.target.value });
  };

  const handleSubmit = () => {
    addBatch(batch); // save batch in context
    navigate('/batch-management');
  };

  return (
    <Box
      sx={{
        width: '100vw',
        minHeight: '100vh',
        backgroundImage: `url(${Images.Background})`,
        backgroundSize: 'cover',
        backgroundPosition: 'center',
        display: 'flex',
        justifyContent: 'center',
        alignItems: 'center',
        py: 5,
      }}
    >
      <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ duration: 1 }}>
        <Paper sx={{ p: 4, minWidth: 400, backdropFilter: 'blur(10px)', backgroundColor: 'rgba(255,255,255,0.8)' }}>
          <Typography variant="h5" gutterBottom>
            Create Medicine Batch
          </Typography>
          <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
            <TextField label="Batch ID" name="batchId" value={batch.batchId} onChange={handleChange} />
            <TextField label="Medicine Name" name="medicineName" value={batch.medicineName} onChange={handleChange} />
            <TextField label="Manufacturer" name="manufacturer" value={batch.manufacturer} onChange={handleChange} />
            <TextField
              label="Manufacture Date"
              type="date"
              name="manufactureDate"
              value={batch.manufactureDate}
              onChange={handleChange}
              InputLabelProps={{ shrink: true }}
            />
            <TextField
              label="Expiry Date"
              type="date"
              name="expiryDate"
              value={batch.expiryDate}
              onChange={handleChange}
              InputLabelProps={{ shrink: true }}
            />
            <TextField label="Quantity" name="quantity" value={batch.quantity} onChange={handleChange} />
            <TextField label="Price per Unit" name="price" value={batch.price} onChange={handleChange} />
            <TextField label="Current Owner / Role" name="currentOwner" value={batch.currentOwner} onChange={handleChange} />
            <Button variant="contained" sx={{ mt: 2 }} onClick={handleSubmit}>
              Create Batch
            </Button>
          </Box>
        </Paper>
      </motion.div>
    </Box>
  );
}
