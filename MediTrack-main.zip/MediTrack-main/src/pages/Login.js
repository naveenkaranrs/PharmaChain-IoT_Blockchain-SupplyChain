import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Container, Box, TextField, Button, Typography, Paper, MenuItem } from '@mui/material';
import { motion } from 'framer-motion';
import Images from '../Asset/Image';

export default function Login() {
  const navigate = useNavigate();
  const [id, setId] = useState('');
  const [password, setPassword] = useState('');
  const [role, setRole] = useState('');
  const [error, setError] = useState('');

  // ✅ Predefined credentials for each role
  const credentials = {
    Manufacture: { id: 'MANUFACTURE', password: 'MANUFACTURE' },
    Testing: { id: 'TESTING', password: 'TESTING' },
    Shipping: { id: 'SHIPPING', password: 'SHIPPING' },
    Delivery: { id: 'DELIVERY', password: 'DELIVERY' },
    Patient: { id: 'PATIENT', password: 'PATIENT' }, // ✅ Patient added
  };

  const roles = Object.keys(credentials);

  const handleLogin = () => {
    if (!role) {
      setError('Please select a role.');
      return;
    }

    const user = credentials[role];
    if (user && user.id === id && user.password === password) {
      setError('');

      // ✅ Navigate based on selected role
      if (role === 'Manufacture') navigate('/batch-management');
      else if (role === 'Testing') navigate('/testing');
      else if (role === 'Shipping') navigate('/shipping');
      else if (role === 'Delivery') navigate('/delivery');
      else if (role === 'Patient') navigate('/patient-tracking'); // ✅ Patient page
    } else {
      setError('Invalid ID or Password');
    }
  };

  return (
    <Container
      maxWidth={false}
      sx={{
        width: '100vw',
        height: '100vh',
        display: 'flex',
        justifyContent: 'center',
        alignItems: 'center',
        backgroundImage: `url(${Images.Background})`,
        backgroundSize: 'cover',
        backgroundPosition: 'center',
      }}
    >
      <motion.div
        initial={{ opacity: 0, y: -50 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 1 }}
      >
        <Paper
          elevation={6}
          sx={{
            padding: 4,
            display: 'flex',
            flexDirection: 'column',
            alignItems: 'center',
            backdropFilter: 'blur(10px)',
            backgroundColor: 'rgba(255, 255, 255, 0.8)',
            minWidth: 350,
          }}
        >
          <Typography component="h1" variant="h5">
            Login
          </Typography>
          <Box component="form" sx={{ mt: 2 }}>
            <TextField
              fullWidth
              label="ID"
              margin="normal"
              value={id}
              onChange={(e) => setId(e.target.value)}
            />
            <TextField
              fullWidth
              label="Password"
              type="password"
              margin="normal"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
            />
            <TextField
              select
              fullWidth
              label="Role"
              margin="normal"
              value={role}
              onChange={(e) => setRole(e.target.value)}
            >
              {roles.map((option) => (
                <MenuItem key={option} value={option}>
                  {option}
                </MenuItem>
              ))}
            </TextField>

            {error && (
              <Typography color="error" sx={{ mt: 1, textAlign: 'center' }}>
                {error}
              </Typography>
            )}

            <Button fullWidth variant="contained" sx={{ mt: 2 }} onClick={handleLogin}>
              Sign In
            </Button>
          </Box>
        </Paper>
      </motion.div>
    </Container>
  );
}
