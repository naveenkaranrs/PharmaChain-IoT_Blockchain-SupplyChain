// pages/TransferBatch.js
import React, { useContext, useState } from 'react';
import { Container, Typography, Paper, Box, Button, MenuItem, TextField } from '@mui/material';
import { BatchContext } from '../context/BatchContext';
import Images from '../Asset/Image';
import { motion } from 'framer-motion';

export default function TransferBatch() {
  const { batches, updateBatchOwner } = useContext(BatchContext);
  const [selectedBatch, setSelectedBatch] = useState('');
  const [newOwner, setNewOwner] = useState('');

  const handleTransfer = () => {
    if (selectedBatch && newOwner) {
      updateBatchOwner(selectedBatch, newOwner);
      alert('Batch transferred!');
      setSelectedBatch('');
      setNewOwner('');
    }
  };

  return (
    <Box
      sx={{
        width: '100vw',
        minHeight: '100vh',
        backgroundImage: `url(${Images.Background})`,
        backgroundSize: 'cover',
        backgroundPosition: 'center',
        display: 'flex',
        justifyContent: 'center',
        alignItems: 'center',
        py: 5,
      }}
    >
      <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ duration: 1 }}>
        <Paper sx={{ p: 4, minWidth: 400, backdropFilter: 'blur(10px)', backgroundColor: 'rgba(255,255,255,0.8)' }}>
          <Typography variant="h5" gutterBottom>
            Transfer Medicine Batch
          </Typography>

          {batches.length === 0 ? (
            <Typography>No batches available. Create a batch first.</Typography>
          ) : (
            <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
              <TextField
                select
                label="Select Batch"
                value={selectedBatch}
                onChange={(e) => setSelectedBatch(e.target.value)}
              >
                {batches.map((batch) => (
                  <MenuItem key={batch.batchId} value={batch.batchId}>
                    {batch.medicineName} (ID: {batch.batchId})
                  </MenuItem>
                ))}
              </TextField>

              <TextField
                label="New Owner / Role"
                value={newOwner}
                onChange={(e) => setNewOwner(e.target.value)}
              />

              <Button variant="contained" onClick={handleTransfer}>
                Transfer Batch
              </Button>
            </Box>
          )}

          <Box sx={{ mt: 3 }}>
            <Typography variant="h6">All Batches</Typography>
            {batches.map((batch) => (
              <Box key={batch.batchId} sx={{ p: 1, borderBottom: '1px solid gray' }}>
                <Typography>
                  {batch.medicineName} | ID: {batch.batchId} | Owner: {batch.currentOwner}
                </Typography>
              </Box>
            ))}
          </Box>
        </Paper>
      </motion.div>
    </Box>
  );
}
