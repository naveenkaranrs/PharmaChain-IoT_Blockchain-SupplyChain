import React, { useContext, useState } from "react";
import {
  Container,
  Typography,
  Paper,
  Table,
  TableHead,
  TableRow,
  TableCell,
  TableBody,
  TextField,
  Button,
  MenuItem,
} from "@mui/material";
import { motion } from "framer-motion";
import { BatchContext } from "../context/BatchContext";

export default function Testing() {
  const { batches, updateTestResult } = useContext(BatchContext);
  const [testResults, setTestResults] = useState({});
  const [pendingBatches, setPendingBatches] = useState(batches); // ✅ Local copy for visible list

  const handleChange = (batchId, field, value) => {
    setTestResults((prev) => ({
      ...prev,
      [batchId]: { ...prev[batchId], [field]: value },
    }));
  };

  const handleSubmit = (batchId) => {
    const data = testResults[batchId];
    if (!data?.status || !data?.remarks || !data?.goodLevel || !data?.safeProduct) {
      alert("Please fill all fields before submitting.");
      return;
    }

    updateTestResult(batchId, data); // ✅ Save test result to global context
    alert(`Batch ${batchId} marked as ${data.status}`);

    // ✅ Remove batch from current list after testing
    setPendingBatches((prev) => prev.filter((b) => b.batchId !== batchId));
  };

  return (
    <Container
      maxWidth={false}
      sx={{
        width: "100vw",
        height: "100vh",
        backgroundColor: "#eef2f7",
        padding: 4,
      }}
    >
      <motion.div
        initial={{ opacity: 0, y: -30 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 1 }}
      >
        <Typography variant="h4" sx={{ mb: 3, textAlign: "center" }}>
          Testing Dashboard
        </Typography>

        <Paper sx={{ p: 3 }}>
          {pendingBatches.length === 0 ? (
            <Typography color="text.secondary">
              ✅ All batches have been tested.
            </Typography>
          ) : (
            <Table>
              <TableHead>
                <TableRow>
                  <TableCell>Batch ID</TableCell>
                  <TableCell>Product Name</TableCell>
                  <TableCell>Good Level</TableCell>
                  <TableCell>Safe Product</TableCell>
                  <TableCell>Remarks</TableCell>
                  <TableCell>Status</TableCell>
                  <TableCell>Action</TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {pendingBatches.map((batch) => (
                  <TableRow key={batch.batchId}>
                    <TableCell>{batch.batchId}</TableCell>
                    <TableCell>{batch.productName}</TableCell>
                    <TableCell>
                      <TextField
                        size="small"
                        onChange={(e) =>
                          handleChange(batch.batchId, "goodLevel", e.target.value)
                        }
                      />
                    </TableCell>
                    <TableCell>
                      <TextField
                        select
                        size="small"
                        onChange={(e) =>
                          handleChange(batch.batchId, "safeProduct", e.target.value)
                        }
                      >
                        <MenuItem value="Yes">Yes</MenuItem>
                        <MenuItem value="No">No</MenuItem>
                      </TextField>
                    </TableCell>
                    <TableCell>
                      <TextField
                        size="small"
                        onChange={(e) =>
                          handleChange(batch.batchId, "remarks", e.target.value)
                        }
                      />
                    </TableCell>
                    <TableCell>
                      <TextField
                        select
                        size="small"
                        onChange={(e) =>
                          handleChange(batch.batchId, "status", e.target.value)
                        }
                      >
                        <MenuItem value="Approved">Approved</MenuItem>
                        <MenuItem value="Rejected">Rejected</MenuItem>
                      </TextField>
                    </TableCell>
                    <TableCell>
                      <Button
                        variant="contained"
                        size="small"
                        onClick={() => handleSubmit(batch.batchId)}
                      >
                        Submit
                      </Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </Paper>
      </motion.div>
    </Container>
  );
}
