import React, { useContext } from "react";
import {
  Box,
  Typography,
  Paper,
  Button,
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableRow,
} from "@mui/material";
import { motion } from "framer-motion";
import jsPDF from "jspdf";
import QRCode from "qrcode";
import Images from "../Asset/Image";
import { BatchContext } from "../context/BatchContext";

export default function ViewBatches() {
  const { batches } = useContext(BatchContext);

  // Animation variants
  const cardVariants = {
    hidden: { opacity: 0, y: 50 },
    visible: (i) => ({
      opacity: 1,
      y: 0,
      transition: { delay: i * 0.2, duration: 0.5, type: "spring", stiffness: 100 },
    }),
  };

  // Generate QR Code
  const generateQRCode = async (batch) => {
    try {
      const qrData = JSON.stringify({
        batchId: batch.batchId,
        medicineName: batch.medicineName,
        currentOwner: batch.currentOwner,
      });
      const qrUrl = await QRCode.toDataURL(qrData);
      return qrUrl;
    } catch (error) {
      console.error("QR code generation error:", error);
      return null;
    }
  };

  // Download PDF Report
  const handleDownloadReport = async (batch) => {
    const doc = new jsPDF();

    // Title
    doc.setFontSize(18);
    doc.text("Medicine Batch Report", 20, 20);

    // Batch Info
    doc.setFontSize(12);
    doc.text(`Batch ID: ${batch.batchId}`, 20, 40);
    doc.text(`Medicine Name: ${batch.medicineName}`, 20, 50);
    doc.text(`Manufacturer: ${batch.manufacturer}`, 20, 60);
    doc.text(`Manufacture Date: ${batch.manufactureDate}`, 20, 70);
    doc.text(`Expiry Date: ${batch.expiryDate}`, 20, 80);
    doc.text(`Quantity: ${batch.quantity}`, 20, 90);
    doc.text(`Price per Unit: ${batch.price}`, 20, 100);
    doc.text(`Current Owner: ${batch.currentOwner}`, 20, 110);

    // IoT Data
    if (batch.iotData) {
      doc.text(`Temperature: ${batch.iotData.temperature}°C`, 20, 130);
      doc.text(`Humidity: ${batch.iotData.humidity}%`, 20, 140);
    }

    // Add QR Code
    const qrUrl = await generateQRCode(batch);
    if (qrUrl) {
      doc.addImage(qrUrl, "PNG", 140, 40, 50, 50);
    }

    // Transaction History
    if (batch.transactions && batch.transactions.length > 0) {
      doc.text("Transaction History:", 20, 160);
      let y = 170;
      batch.transactions.forEach((tx, index) => {
        doc.text(
          `${index + 1}. ${tx.date} | From: ${tx.from} → To: ${tx.to} | Status: ${tx.status}`,
          20,
          y
        );
        y += 10;
      });
    }

    // Save file
    doc.save(`${batch.medicineName || "batch"}_report.pdf`);
  };

  return (
    <Box
      sx={{
        width: "100vw",
        minHeight: "100vh",
        backgroundImage: `url(${Images.Background})`,
        backgroundSize: "cover",
        backgroundPosition: "center",
        display: "flex",
        justifyContent: "center",
        alignItems: "flex-start",
        py: 5,
      }}
    >
      <Box sx={{ width: "90%", maxWidth: 1200 }}>
        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ duration: 1 }}>
          <Typography
            variant="h4"
            gutterBottom
            sx={{ color: "white", textShadow: "1px 1px 5px black", mb: 4 }}
          >
            All Medicine Batches
          </Typography>
        </motion.div>

        <Box sx={{ display: "flex", flexDirection: "column", gap: 3 }}>
          {batches.length === 0 ? (
            <Typography sx={{ color: "white" }}>
              No batches available. Create a batch first.
            </Typography>
          ) : (
            batches.map((batch, index) => (
              <motion.div
                key={batch.batchId}
                custom={index}
                initial="hidden"
                animate="visible"
                variants={cardVariants}
              >
                <Paper
                  sx={{
                    p: 3,
                    backdropFilter: "blur(10px)",
                    backgroundColor: "rgba(255, 255, 255, 0.9)",
                    cursor: "default",
                    ":hover": {
                      transform: "scale(1.03)",
                      boxShadow: "0 8px 20px rgba(0,0,0,0.3)",
                    },
                  }}
                >
                  <Typography variant="h6">{batch.medicineName}</Typography>
                  <Typography>Batch ID: {batch.batchId}</Typography>
                  <Typography>Manufacturer: {batch.manufacturer}</Typography>
                  <Typography>Manufacture Date: {batch.manufactureDate}</Typography>
                  <Typography>Expiry Date: {batch.expiryDate}</Typography>
                  <Typography>Quantity: {batch.quantity}</Typography>
                  <Typography>Price per Unit: {batch.price}</Typography>
                  <Typography>Current Owner: {batch.currentOwner}</Typography>

                  {batch.iotData && (
                    <Box sx={{ mt: 2 }}>
                      <Typography variant="subtitle1">IoT Data:</Typography>
                      <Typography>Temperature: {batch.iotData.temperature}°C</Typography>
                      <Typography>Humidity: {batch.iotData.humidity}%</Typography>
                    </Box>
                  )}

                  {batch.transactions && batch.transactions.length > 0 && (
                    <Box sx={{ mt: 2 }}>
                      <Typography variant="subtitle1">Transaction History:</Typography>
                      <Table size="small">
                        <TableHead>
                          <TableRow>
                            <TableCell>Date</TableCell>
                            <TableCell>From</TableCell>
                            <TableCell>To</TableCell>
                            <TableCell>Status</TableCell>
                          </TableRow>
                        </TableHead>
                        <TableBody>
                          {batch.transactions.map((tx, idx) => (
                            <TableRow key={idx}>
                              <TableCell>{tx.date}</TableCell>
                              <TableCell>{tx.from}</TableCell>
                              <TableCell>{tx.to}</TableCell>
                              <TableCell>{tx.status}</TableCell>
                            </TableRow>
                          ))}
                        </TableBody>
                      </Table>
                    </Box>
                  )}

                  <Box sx={{ mt: 2, display: "flex", gap: 2 }}>
                    <Button variant="contained" size="small">
                      View History
                    </Button>

                    <Button
                      variant="outlined"
                      size="small"
                      onClick={async () => {
                        const qrUrl = await generateQRCode(batch);
                        if (qrUrl) {
                          const newWindow = window.open();
                          newWindow.document.write(`<img src="${qrUrl}" alt="QR Code" />`);
                        }
                      }}
                    >
                      Scan QR
                    </Button>

                    <Button
                      variant="outlined"
                      size="small"
                      onClick={() => handleDownloadReport(batch)}
                    >
                      Download Report
                    </Button>
                  </Box>
                </Paper>
              </motion.div>
            ))
          )}
        </Box>
      </Box>
    </Box>
  );
}
