// pages/BatchManagement.js
import React from 'react';
import { Container, Typography, Button, Box, Paper } from '@mui/material';
import { motion } from 'framer-motion';
import { useNavigate } from 'react-router-dom';
import Images from '../Asset/Image'; // Same background as login

export default function BatchManagement() {
  const navigate = useNavigate();

  // Animation variants for cards
  const cardVariants = {
    hidden: { opacity: 0, y: 50 },
    visible: (i) => ({
      opacity: 1,
      y: 0,
      transition: { delay: i * 0.2, duration: 0.5, type: 'spring', stiffness: 100 },
    }),
  };

  // Dashboard cards with title and route
  const cards = [
    { title: 'Create Medicine Batch', route: '/create-batch' },
    { title: 'Transfer Medicine Batch', route: '/transfer-batch' },
    { title: 'View Medicine Batches', route: '/view-batches' },
  ];

  return (
    <Box
      sx={{
        width: '100vw',
        minHeight: '100vh',
        backgroundImage: `url(${Images.Background})`,
        backgroundSize: 'cover',
        backgroundPosition: 'center',
        display: 'flex',
        justifyContent: 'center',
        alignItems: 'flex-start',
        py: 5,
      }}
    >
      <Container>
        {/* Dashboard Title */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 1 }}
        >
          <Typography
            variant="h4"
            gutterBottom
            sx={{ color: 'white', textShadow: '1px 1px 5px black' }}
          >
            Batch Management Dashboard
          </Typography>
        </motion.div>

        {/* Dashboard Cards */}
        <Box sx={{ display: 'flex', gap: 3, flexWrap: 'wrap', mt: 3 }}>
          {cards.map((card, index) => (
            <motion.div
              key={card.title}
              custom={index}
              initial="hidden"
              animate="visible"
              variants={cardVariants}
            >
              <Paper
                sx={{
                  p: 4,
                  minWidth: 220,
                  display: 'flex',
                  flexDirection: 'column',
                  alignItems: 'center',
                  backdropFilter: 'blur(10px)',
                  backgroundColor: 'rgba(255, 255, 255, 0.8)',
                  cursor: 'pointer',
                  ':hover': {
                    scale: 1.05,
                    boxShadow: '0 8px 20px rgba(0,0,0,0.3)',
                  },
                }}
              >
                <Typography variant="h6" sx={{ mb: 1, textAlign: 'center' }}>
                  {card.title}
                </Typography>
                <Button
                  variant="contained"
                  onClick={() => navigate(card.route)}
                >
                  {card.title.split(' ')[0]}
                </Button>
              </Paper>
            </motion.div>
          ))}
        </Box>
      </Container>
    </Box>
  );
}
