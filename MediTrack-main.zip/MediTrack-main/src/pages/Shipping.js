import React, { useContext } from "react";
import {
  Container,
  Typography,
  Paper,
  Table,
  TableHead,
  TableRow,
  TableCell,
  TableBody,
  Button,
} from "@mui/material";
import { motion } from "framer-motion";
import { BatchContext } from "../context/BatchContext";

export default function Shipping() {
  const { testedBatches, shippedBatches, markAsShipped } =
    useContext(BatchContext);

  const handleShip = (batchId) => {
    markAsShipped(batchId);
    alert(`✅ Batch ${batchId} shipped successfully!`);
  };

  return (
    <Container
      maxWidth={false}
      sx={{
        width: "100vw",
        height: "100vh",
        backgroundColor: "#f8fafc",
        padding: 4,
      }}
    >
      <motion.div
        initial={{ opacity: 0, y: -30 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 1 }}
      >
        <Typography variant="h4" sx={{ mb: 3, textAlign: "center" }}>
          Shipping Dashboard
        </Typography>

        {/* Pending Shipments */}
        <Paper sx={{ p: 3, mb: 4 }}>
          <Typography variant="h6" gutterBottom>
            Approved Batches Ready for Shipping
          </Typography>
          {testedBatches.length === 0 ? (
            <Typography color="text.secondary">
              No approved batches available for shipping.
            </Typography>
          ) : (
            <Table>
              <TableHead>
                <TableRow>
                  <TableCell>Batch ID</TableCell>
                  <TableCell>Product Name</TableCell>
                  <TableCell>Good Level</TableCell>
                  <TableCell>Safe Product</TableCell>
                  <TableCell>Remarks</TableCell>
                  <TableCell>Action</TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {testedBatches.map((batch) => (
                  <TableRow key={batch.batchId}>
                    <TableCell>{batch.batchId}</TableCell>
                    <TableCell>{batch.productName}</TableCell>
                    <TableCell>{batch.testResult?.goodLevel}</TableCell>
                    <TableCell>{batch.testResult?.safeProduct}</TableCell>
                    <TableCell>{batch.testResult?.remarks}</TableCell>
                    <TableCell>
                      <Button
                        variant="contained"
                        color="primary"
                        size="small"
                        onClick={() => handleShip(batch.batchId)}
                      >
                        Ship Now
                      </Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </Paper>

        {/* Shipped Batches */}
        <Paper sx={{ p: 3 }}>
          <Typography variant="h6" gutterBottom>
            Shipped Batches
          </Typography>
          {shippedBatches.length === 0 ? (
            <Typography color="text.secondary">
              No batches have been shipped yet.
            </Typography>
          ) : (
            <Table>
              <TableHead>
                <TableRow>
                  <TableCell>Batch ID</TableCell>
                  <TableCell>Product Name</TableCell>
                  <TableCell>Quantity</TableCell>
                  <TableCell>Status</TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {shippedBatches.map((batch) => (
                  <TableRow key={batch.batchId}>
                    <TableCell>{batch.batchId}</TableCell>
                    <TableCell>{batch.productName}</TableCell>
                    <TableCell>{batch.quantity}</TableCell>
                    <TableCell>Shipped</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </Paper>
      </motion.div>
    </Container>
  );
}
