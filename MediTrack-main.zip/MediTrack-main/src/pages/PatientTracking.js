// src/pages/PatientTracking.js
import React, { useContext, useState } from "react";
import {
  Container,
  Typography,
  Paper,
  TextField,
  Button,
  Box,
  List,
  ListItem,
  ListItemText,
} from "@mui/material";
import { motion } from "framer-motion";
import { BatchContext } from "../context/BatchContext";

export default function PatientTracking() {
  const { batches } = useContext(BatchContext);
  const [batchId, setBatchId] = useState("");
  const [trackingInfo, setTrackingInfo] = useState(null);

  const handleTrack = () => {
    // Find the batch across all records
    const batch = batches.find((b) => b.batchId.trim() === batchId.trim());
    if (!batch) {
      alert("Batch ID not found!");
      setTrackingInfo(null);
      return;
    }

    // Define stages dynamically based on available info
    const stages = [
      { stage: "Manufactured", completed: true },
      { stage: "Tested & Approved", completed: batch.testResult?.status === "Approved" },
      { stage: "Shipped", completed: batch.shipped === true },
      { stage: "Delivered", completed: batch.delivered === true },
    ];

    setTrackingInfo({ batch, stages });
  };

  return (
    <Container
      maxWidth={false}
      sx={{
        width: "100vw",
        height: "100vh",
        backgroundColor: "#eef2f7",
        padding: 4,
      }}
    >
      <motion.div
        initial={{ opacity: 0, y: -30 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 1 }}
      >
        <Typography variant="h4" sx={{ mb: 3, textAlign: "center" }}>
          Patient Batch Tracking
        </Typography>

        <Paper sx={{ p: 3, mb: 4 }}>
          <Box sx={{ display: "flex", gap: 2, alignItems: "center" }}>
            <TextField
              label="Enter Batch ID"
              value={batchId}
              onChange={(e) => setBatchId(e.target.value)}
              size="small"
              fullWidth
            />
            <Button variant="contained" onClick={handleTrack}>
              Track
            </Button>
          </Box>
        </Paper>

        {trackingInfo && (
          <Paper sx={{ p: 3 }}>
            <Typography variant="h6" gutterBottom>
              Tracking Details for Batch ID: {trackingInfo.batch.batchId}
            </Typography>

            <List>
              {trackingInfo.stages.map((stage, idx) => (
                <ListItem key={idx}>
                  <ListItemText
                    primary={stage.stage}
                    secondary={stage.completed ? "✅ Completed" : "❌ Pending"}
                    primaryTypographyProps={{
                      style: {
                        fontWeight: stage.completed ? "bold" : "normal",
                        color: stage.completed ? "green" : "red",
                      },
                    }}
                  />
                </ListItem>
              ))}
            </List>
          </Paper>
        )}
      </motion.div>
    </Container>
  );
}
