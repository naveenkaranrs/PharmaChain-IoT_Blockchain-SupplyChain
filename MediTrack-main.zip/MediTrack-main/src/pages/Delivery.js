import React, { useContext } from "react";
import {
  Container,
  Typography,
  Paper,
  Table,
  TableHead,
  TableRow,
  TableCell,
  TableBody,
  Button,
} from "@mui/material";
import { motion } from "framer-motion";
import { BatchContext } from "../context/BatchContext";

export default function Delivery() {
  const { shippedBatches, markAsDelivered, deliveredBatches } =
    useContext(BatchContext);

  const pendingDeliveries = shippedBatches.filter((b) => !b.delivered);

  const handleDeliver = (batchId) => {
    markAsDelivered(batchId);
    alert(`Batch ${batchId} marked as Delivered!`);
  };

  return (
    <Container
      maxWidth={false}
      sx={{
        width: "100vw",
        height: "100vh",
        backgroundColor: "#eef2f7",
        padding: 4,
      }}
    >
      <motion.div
        initial={{ opacity: 0, y: -30 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 1 }}
      >
        <Typography variant="h4" sx={{ mb: 3, textAlign: "center" }}>
          Delivery Dashboard
        </Typography>

        <Paper sx={{ p: 3, mb: 4 }}>
          <Typography variant="h6" gutterBottom>
            Pending Deliveries
          </Typography>
          {pendingDeliveries.length === 0 ? (
            <Typography color="text.secondary">
              No batches pending for delivery.
            </Typography>
          ) : (
            <Table>
              <TableHead>
                <TableRow>
                  <TableCell>Batch ID</TableCell>
                  <TableCell>Product Name</TableCell>
                  <TableCell>Manufacture Date</TableCell>
                  <TableCell>Expiry Date</TableCell>
                  <TableCell>Quantity</TableCell>
                  <TableCell>Action</TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {pendingDeliveries.map((batch) => (
                  <TableRow key={batch.batchId}>
                    <TableCell>{batch.batchId}</TableCell>
                    <TableCell>{batch.productName}</TableCell>
                    <TableCell>{batch.manufactureDate}</TableCell>
                    <TableCell>{batch.expiryDate}</TableCell>
                    <TableCell>{batch.quantity}</TableCell>
                    <TableCell>
                      <Button
                        variant="contained"
                        color="success"
                        size="small"
                        onClick={() => handleDeliver(batch.batchId)}
                      >
                        Mark Delivered
                      </Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </Paper>

        <Paper sx={{ p: 3 }}>
          <Typography variant="h6" gutterBottom>
            Delivered Batches
          </Typography>
          {deliveredBatches.length === 0 ? (
            <Typography color="text.secondary">
              No delivered batches yet.
            </Typography>
          ) : (
            <Table>
              <TableHead>
                <TableRow>
                  <TableCell>Batch ID</TableCell>
                  <TableCell>Product Name</TableCell>
                  <TableCell>Quantity</TableCell>
                  <TableCell>Status</TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {deliveredBatches.map((batch) => (
                  <TableRow key={batch.batchId}>
                    <TableCell>{batch.batchId}</TableCell>
                    <TableCell>{batch.productName}</TableCell>
                    <TableCell>{batch.quantity}</TableCell>
                    <TableCell style={{ color: "green", fontWeight: "bold" }}>
                      Delivered
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </Paper>
      </motion.div>
    </Container>
  );
}
